module.exports = function getTicketTemplate({ nama, id }) {
  const barcodeUrl = `https://api.qrserver.com/v1/create-qr-code/?data=ID-${id}&size=100x100`;

  return `
  <!DOCTYPE html>
  <html>
  <head>
    <meta charset="UTF-8">
    <title>Tiket ARTFEST REALIZM</title>
    <style>
      body {
        margin: 0;
        padding: 0;
        background-color: #0b0b0b;
        font-family: 'Segoe UI', sans-serif;
        color: #ffffff;
      }
      .ticket {
        width: 600px;
        margin: 40px auto;
        padding: 30px;
        background-color: #111;
        border: 2px solid;
        border-image: linear-gradient(45deg, #00f0ff, #c800ff) 1;
        border-radius: 20px;
        position: relative;
        box-sizing: border-box;
        color: #ffffff;
      }
      .header {
        text-align: center;
        color: #ffffff;
      }
      .header h1 {
        font-size: 32px;
        font-weight: 800;
        margin-bottom: 5px;
        background: linear-gradient(90deg, #00f0ff, #c800ff);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        color: transparent;
      }
      .header p {
        font-size: 14px;
        color: #ffffff;
        margin-top: 0;
      }
      .info {
        margin-top: 20px;
        font-size: 16px;
        line-height: 1.6;
        color: #ffffff;
      }
      .info ul {
        padding-left: 20px;
        color: #ffffff;
      }
      .footer {
        font-size: 12px;
        color: #ffffff;
        margin-top: 30px;
      }
      .barcode {
        position: absolute;
        bottom: 30px;
        right: 30px;
        text-align: right;
        color: #ffffff;
      }
      .barcode img {
        border: 3px solid #5e5eff;
        border-radius: 6px;
      }
      .barcode .id {
        margin-top: 5px;
        font-size: 12px;
        color: #ffffff;
      }
    </style>
  </head>
  <body>
    <div class="ticket">
      <div class="header">
        <h1>ARTFEST REALIZM</h1>
        <p><em>Rancang Momen, Bangun Kenangan</em></p>
      </div>

      <div class="info">
        <p>Halo <strong>${nama}</strong>,</p>
        <p>Berikut tiket digitalmu:</p>
        <ul>
          <li><strong>Tanggal:</strong> 6 September 2025</li>
          <li><strong>Tempat:</strong> Utopia Collaboration Space</li>
        </ul>
      </div>

      <div class="footer">Tunjukkan tiket ini saat check-in di lokasi acara.</div>

      <div class="barcode">
        <img src="${barcodeUrl}" width="100" height="100" alt="QR Code Tiket" />
        <div class="id">ID Tiket: ${id}</div>
      </div>
    </div>
  </body>
  </html>
  `;
};