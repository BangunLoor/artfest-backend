const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'bangunloor@gmail.com',
    pass: 'fago bjdn kovw dqhe'
  }
});

function sendTicketEmail({ email, nama, id }) {
  const barcodeUrl = `https://api.qrserver.com/v1/create-qr-code/?data=ID-${id}&size=100x100`;

  const html = `
  <!DOCTYPE html>
  <html lang="id">
  <head>
    <meta charset="UTF-8" />
    <title>Artfest Realizm Ticket</title>
  </head>
  <body style="margin:0; padding:0; background-color:#0b0b0b; font-family:'Montserrat',sans-serif; color:#fff;">
    <div style="max-width:400px; margin:40px auto; border:2px solid; border-image:linear-gradient(45deg, #00f0ff, #c800ff) 1; border-radius:20px; padding:30px; background-color:#111; box-shadow:0 0 30px rgba(0,255,255,0.2); text-align:center;">

      <h1 style="font-size:32px; font-weight:900; margin:0; line-height:1.2;
        background:linear-gradient(90deg, #00f0ff, #c800ff);
        -webkit-background-clip:text; -webkit-text-fill-color:transparent;">
        ARTFEST<br>REALIZM
      </h1>

      <p style="color:#ccc; font-size:14px; margin:10px 0 30px;">
        Rancang Momen, Bangun Kenangan.
      </p>

      <hr style="border:0; border-bottom:1px solid #333; margin:20px 0;" />

      <div style="font-size:14px; margin-bottom: 10px;">
        Halo <strong>${nama}</strong>, berikut adalah tiket digitalmu.
      </div>

      <div style="display:flex; align-items:center; justify-content:center; gap:10px; color:#fff; margin-bottom:20px;">
        <img src="https://img.icons8.com/ios-filled/20/ffffff/calendar--v1.png" alt="calendar" width="20" height="20"/>
        <div style="font-size:16px; font-weight:600;">06 SEPTEMBER 2025</div>
      </div>

      <hr style="border:0; border-bottom:1px solid #333; margin:20px 0;" />

      <div style="display:flex; justify-content:space-between; align-items:center;">
        <div style="display:flex; align-items:center; gap:10px; text-align:left;">
          <img src="https://img.icons8.com/ios-filled/20/ffffff/marker.png" alt="location" width="20" height="20"/>
          <div>
            <div style="font-weight:bold; font-size:18px;">UTOPIA</div>
            <div style="font-weight:500; font-size:14px;">COLLABORATION SPACE</div>
          </div>
        </div>

        <div style="text-align:right;">
          <img src="${barcodeUrl}" alt="QR Code" width="100" height="100" style="display:block; margin-bottom:5px;" />
          <div style="font-size:12px; color:#aaa;">ID Tiket: ${id}</div>
        </div>
      </div>

      <p style="margin-top: 30px; font-size: 12px; color: #777;">Tunjukkan tiket ini saat hadir di lokasi.</p>
    </div>
  </body>
  </html>
  `;

  const mailOptions = {
    from: '"Artfest Realizm" <bangunloor@gmail.com>',
    to: email,
    subject: '🎫 Tiket Digital - ARTFEST REALIZM',
    html
  };

  return transporter.sendMail(mailOptions);
}

module.exports = { sendTicketEmail };
