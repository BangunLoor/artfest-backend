const nodemailer = require('nodemailer');
const QRCode = require('qrcode');
const PDFDocument = require('pdfkit');
const fs = require('fs');

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'bangunloor@gmail.com',
    pass: 'fago bjdn kovw dqhe'
  }
});

async function sendTicketEmail(data) {
  const qrData = `ARTFEST|${data.id}|${data.nama}|${data.email}`;
  const qrImage = await QRCode.toDataURL(qrData);

  const pdfPath = `public/uploads/tiket-${data.id}.pdf`;
  const doc = new PDFDocument();
  doc.pipe(fs.createWriteStream(pdfPath));
  doc.fontSize(18).text('E-Ticket Artfest Realizm', { align: 'center' });
  doc.moveDown();
  doc.text(`Nama: ${data.nama}`);
  doc.text(`Email: ${data.email}`);
  doc.image(qrImage, { width: 150 });
  doc.end();

  await transporter.sendMail({
    from: 'Artfest Realizm <bangunloor@gmail.com>',
    to: data.email,
    subject: 'Tiket Artfest Realizm',
    text: 'Berikut tiket Anda',
    attachments: [{ filename: 'tiket.pdf', path: pdfPath }]
  });
}

module.exports = { sendTicketEmail };
