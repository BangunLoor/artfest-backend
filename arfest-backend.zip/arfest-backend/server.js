const express = require('express');
const bodyParser = require('body-parser');
const multer = require('multer');
const fs = require('fs');
const cors = require('cors');
const path = require('path');
const { sendTicketEmail } = require('./utils/sendEmail');

const app = express();

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'));

// Static files
app.use('/admin', express.static(path.join(__dirname, 'views')));
app.use('/scanner', express.static(path.join(__dirname, 'views/scanner')));

// Upload bukti pembayaran
const storage = multer.diskStorage({
  destination: './public/uploads/',
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});
const upload = multer({ storage });

const dataFile = 'transactions.json';

// Endpoint kirim data pembelian
app.post('/api/submit', upload.single('bukti'), (req, res) => {
  const { nama, email, hp } = req.body;
  const bukti = req.file?.filename || '';
  const newData = { id: Date.now(), nama, email, hp, bukti, status: 'pending' };

  const existing = fs.existsSync(dataFile) ? JSON.parse(fs.readFileSync(dataFile)) : [];
  existing.push(newData);
  fs.writeFileSync(dataFile, JSON.stringify(existing, null, 2));
  res.json({ success: true });
});

// Endpoint konfirmasi admin & kirim tiket
app.post('/api/konfirmasi', async (req, res) => {
  const { id } = req.body;
  const data = JSON.parse(fs.readFileSync(dataFile));
  const transaksi = data.find(t => t.id === id);

  if (!transaksi) return res.status(404).json({ error: 'Transaksi tidak ditemukan' });

  transaksi.status = 'confirmed';
  fs.writeFileSync(dataFile, JSON.stringify(data, null, 2));
  await sendTicketEmail(transaksi);
  res.json({ success: true });
});

// Endpoint validasi barcode dari scanner
app.post('/api/validasi-barcode', (req, res) => {
  const { code } = req.body;
  const data = fs.existsSync(dataFile) ? JSON.parse(fs.readFileSync(dataFile)) : [];

  const transaksi = data.find(t => t.id.toString() === code);
  if (!transaksi) {
    return res.status(404).json({ valid: false, message: 'Tiket tidak ditemukan' });
  }

  if (transaksi.status === 'used') {
    return res.status(400).json({ valid: false, message: 'Tiket sudah digunakan' });
  }

  if (transaksi.status !== 'confirmed') {
    return res.status(400).json({ valid: false, message: 'Tiket belum dikonfirmasi' });
  }

  transaksi.status = 'used';
  fs.writeFileSync(dataFile, JSON.stringify(data, null, 2));
  res.json({ valid: true, message: 'Tiket valid dan berhasil digunakan' });
});

// Endpoint melihat semua transaksi (admin)
app.get('/api/list', (req, res) => {
  const data = fs.existsSync(dataFile) ? JSON.parse(fs.readFileSync(dataFile)) : [];
  res.json(data);
});

// Default endpoint
app.get('/', (req, res) => {
  res.send('Artfest Realizm Backend Active');
});

// Jalankan server
app.listen(3000, () => console.log('✅ Server running on port 3000'));
